#include "stdafx.h"
#include "SerialPort.h"

communicate::serial::Serial g_serialport;
namespace Serials
{

}