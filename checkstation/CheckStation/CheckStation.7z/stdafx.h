// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <iostream>
//#include <windows.h>

//#include "tbb/tbb.h"
//#include "tbb/parallel_for.h"
//#include "tbb/blocked_range2d.h"
//#include "tbb/partitioner.h"
//#include "opencv2/opencv.hpp"
//#include "ipps.h"
//#include "ippi.h"
// TODO: reference additional headers your program requires here
