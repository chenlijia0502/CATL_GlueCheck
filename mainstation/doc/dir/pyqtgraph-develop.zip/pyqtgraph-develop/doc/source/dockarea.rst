Dock Area Module
================

.. automodule:: pyqtgraph.dockarea
    :members:

.. autoclass:: pyqtgraph.dockarea.DockArea
    :members:

.. autoclass:: pyqtgraph.dockarea.Dock
    :members:
