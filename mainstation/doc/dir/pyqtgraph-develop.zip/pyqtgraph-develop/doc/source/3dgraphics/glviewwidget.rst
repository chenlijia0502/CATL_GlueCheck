GLViewWidget
============

.. autoclass:: pyqtgraph.opengl.GLViewWidget
    :members:

    .. automethod:: pyqtgraph.opengl.GLViewWidget.__init__

