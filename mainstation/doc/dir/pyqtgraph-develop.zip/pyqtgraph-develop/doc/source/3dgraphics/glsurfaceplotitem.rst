GLSurfacePlotItem
=================

.. autoclass:: pyqtgraph.opengl.GLSurfacePlotItem
    :members:

    .. automethod:: pyqtgraph.opengl.GLSurfacePlotItem.__init__

