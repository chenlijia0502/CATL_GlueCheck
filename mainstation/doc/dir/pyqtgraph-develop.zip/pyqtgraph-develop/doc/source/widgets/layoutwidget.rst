LayoutWidget
============

.. autoclass:: pyqtgraph.LayoutWidget
    :members:

    .. automethod:: pyqtgraph.LayoutWidget.__init__

