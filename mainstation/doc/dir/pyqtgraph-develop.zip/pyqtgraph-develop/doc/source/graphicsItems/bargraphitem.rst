BarGraphItem
============

.. autoclass:: pyqtgraph.BarGraphItem
    :members:

    .. automethod:: pyqtgraph.BarGraphItem.__init__

