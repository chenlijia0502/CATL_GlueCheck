AxisItem
========

.. autoclass:: pyqtgraph.AxisItem
    :members:

    .. automethod:: pyqtgraph.AxisItem.__init__

