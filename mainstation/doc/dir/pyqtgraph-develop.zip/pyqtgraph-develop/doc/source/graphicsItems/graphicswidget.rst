GraphicsWidget
==============

.. autoclass:: pyqtgraph.GraphicsWidget
    :members:

    .. automethod:: pyqtgraph.GraphicsWidget.__init__

