ButtonItem
==========

.. autoclass:: pyqtgraph.ButtonItem
    :members:

    .. automethod:: pyqtgraph.ButtonItem.__init__

