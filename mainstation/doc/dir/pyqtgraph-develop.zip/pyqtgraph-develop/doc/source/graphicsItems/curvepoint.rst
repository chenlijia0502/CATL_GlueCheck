CurvePoint
==========

.. autoclass:: pyqtgraph.CurvePoint
    :members:

    .. automethod:: pyqtgraph.CurvePoint.__init__

